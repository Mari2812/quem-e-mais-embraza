
const app = document.getElementById("app");
let players = [];
let scores = {};
let currentCategory = "sincerao";
const questions = {
  sincerao: [
    "falar demais e depois se arrepender?",
    "guardar rancor por semanas?",
    "chegar atrasado em compromissos?"
  ],
  pesadao: [
    "trair e negar até morrer?",
    "cancelar alguém por vingança?",
    "usar chantagem emocional?"
  ]
};

function setup() {
  app.innerHTML = \`
    <div>
      <h2>Adicione os Jogadores</h2>
      <input type="text" id="playerName" placeholder="Nome do jogador" />
      <button onclick="addPlayer()">Adicionar</button>
      <div class="players-list" id="playersList"></div>
      <button onclick="startGame()">Começar Jogo</button>
    </div>
  \`;
}

function addPlayer() {
  const input = document.getElementById("playerName");
  const name = input.value.trim();
  if (name && !players.includes(name)) {
    players.push(name);
    scores[name] = 0;
    input.value = "";
    updatePlayersList();
  }
}

function updatePlayersList() {
  const list = document.getElementById("playersList");
  list.innerHTML = "";
  players.forEach(name => {
    const div = document.createElement("div");
    div.className = "player-tag";
    div.textContent = name;
    list.appendChild(div);
  });
}

function startGame() {
  if (players.length < 2) {
    alert("Adicione pelo menos 2 jogadores!");
    return;
  }
  nextQuestion();
}

function nextQuestion() {
  const category = currentCategory;
  const qList = questions[category];
  const q = qList[Math.floor(Math.random() * qList.length)];
  app.innerHTML = \`
    <div class="card">
      <h3>${category === "sincerao" ? "Sincerão" : "Pesadão"}</h3>
      <p>Quem é mais provável de ${q}</p>
      <div class="player-options">
        ${players.map(p => \`<div class="player-option" onclick="vote('\${p}')">\${p}</div>\`).join("")}
      </div>
    </div>
  \`;
}

function vote(player) {
  scores[player]++;
  nextQuestion();
}

setup();
